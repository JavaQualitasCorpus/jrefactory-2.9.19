
     var oldElem;
     function setSelected(id) {
       var elem;
       if (oldElem) {
          oldElem.className=null;
       }
       if (document.all) {
          elem = document.all(id);
       } else if (document.getElementById) {
          elem = document.getElementById(id);
       }
       if (elem) {
          elem.className="nav_selected";
          oldElem = elem;
       }
       return true;
     }

